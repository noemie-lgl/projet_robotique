import vrep
import math

def to_rad(deg):
    return 2*math.pi*deg/360

def to_deg(rad):
    return rad*360/(2*math.pi)

class VrepManipulatorSimulation:
    def __init__(self):

        self.ip = '127.0.0.1'
        self.port = 19997
        self.scene = './simu.ttt'

# A CHANGER
        self.gain = 0.1
        self.initial_position = [0.5947, 0, 0.4524,0] 

        self.h= 0.1873
        self.l1= 0.3056
        self.l2=0.3237
        self.l3=0.1249


        print('New manipulator simulation started')
        vrep.simxFinish(-1)
        self.client_id = vrep.simxStart(self.ip, self.port, True, True, 5000, 5)

        if self.client_id!=-1:
            print ('Connected to remote API server on %s:%s' % (self.ip, self.port))
            res = vrep.simxLoadScene(self.client_id, self.scene, 1, vrep.simx_opmode_oneshot_wait)
            res, self.manipulator = vrep.simxGetObjectHandle(self.client_id, 'redundantRobot', vrep.simx_opmode_oneshot_wait)
            res, self.joint1= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint1', vrep.simx_opmode_oneshot_wait)
            res, self.joint2= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint2', vrep.simx_opmode_oneshot_wait)
            res, self.joint3= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint3', vrep.simx_opmode_oneshot_wait)
            res, self.joint4= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint4', vrep.simx_opmode_oneshot_wait)
            res, self.joint5= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint5', vrep.simx_opmode_oneshot_wait)
            res, self.joint6= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint6', vrep.simx_opmode_oneshot_wait)
            res, self.joint7= vrep.simxGetObjectHandle(self.client_id, 'redundantRob_joint7', vrep.simx_opmode_oneshot_wait)

            res, self.tip=vrep.simxGetObjectHandle(self.client_id, 'redundantRob_tip', vrep.simx_opmode_oneshot_wait)

            #désactiver l'inverse kinematic!!!!

            #self.set_position(self.initial_position)
            self.set_motor_velocity([0, 0, 0])
            vrep.simxStartSimulation(self.client_id, vrep.simx_opmode_oneshot_wait)

        else:
            print('Unable to connect to %s:%s' % (self.ip, self.port))

    def set_position(self, position):
        """Set the position (x,z,theta) of the tip of the manipulator

        Args:
            position (list): the position [x,z,theta]     theta dans le plan de l'objet??
        """

        vrep.simxSetObjectPosition(self.client_id, self.tip, -1, [position[0], -0.0250, position[1]], vrep.simx_opmode_oneshot_wait)
        vrep.simxSetObjectOrientation(self.client_id, self.tip, -1, [0, -to_deg(position[2])+90, 0], vrep.simx_opmode_oneshot_wait) # +90 pour g�rer le fait que notre theta correspond � b-90

    def get_position(self):
        """Get the position (x,z,theta) of the robot

        Return:
            position (list): the position [x,z,theta]
        """
        position = []
        res, tmp = vrep.simxGetObjectPosition(self.client_id, self.tip, -1, vrep.simx_opmode_oneshot_wait)
        position.append(tmp[0]) #x
        position.append(tmp[2]) #z

        res, tmp = vrep.simxGetObjectOrientation(self.client_id, self.tip, -1, vrep.simx_opmode_oneshot_wait)
        position.append(tmp[1]) # angle dans le plan (0,x,z) en radian 

        return position

    def set_motor_velocity(self, control):
        """Set a target velocity on the manipulator motors, multiplied by the gain
        defined in self.gain

        Args:
            control(list): the control [joint1, joint2, joint3]
        """
        vrep.simxSetJointTargetVelocity(self.client_id, self.joint2, self.gain*control[0], vrep.simx_opmode_oneshot_wait) #velocity en deg/s!!
        vrep.simxSetJointTargetVelocity(self.client_id, self.joint4, self.gain*control[1], vrep.simx_opmode_oneshot_wait)
        vrep.simxSetJointTargetVelocity(self.client_id, self.joint6, self.gain*control[2], vrep.simx_opmode_oneshot_wait)


        #on bloque 4 joints, A PRIORI suffit de les mettre en passive mode sur vrep
        #vrep.simxSetJointTargetVelocity(self.client_id, self.joint1, 0, vrep.simx_opmode_oneshot_wait)
        #vrep.simxSetJointTargetVelocity(self.client_id, self.joint3, 0, vrep.simx_opmode_oneshot_wait)
        #vrep.simxSetJointTargetVelocity(self.client_id, self.joint5, 0, vrep.simx_opmode_oneshot_wait)
        #vrep.simxSetJointTargetVelocity(self.client_id, self.joint7, 0, vrep.simx_opmode_oneshot_wait)
