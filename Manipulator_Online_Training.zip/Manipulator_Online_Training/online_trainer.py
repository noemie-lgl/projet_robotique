import time
import math


def theta_s(x,y):
    if x>0:
        return 1*math.atan(1*y)
    if x<=0:
        return 1*math.atan(-1*y)

class OnlineTrainer:
    def __init__(self, robot, NN):
        """
        Args:
            robot (Robot): a robot instance following the pattern of
                VrepManipulatorSimulation
            target (list): the target position [x,z,theta]
        """
        self.robot = robot
        self.network = NN

        self.alpha = [1.0/1.453,1/0.9,1.0/(math.pi)]  
       

    def train(self, target):
        position = self.robot.get_position()

        network_input = [0, 0, 0]
        network_input[0] = (position[0]-target[0])*self.alpha[0] #X
        network_input[1] = (position[1]-target[1])*self.alpha[1] #Z
        network_input[2] = (position[2]-target[2])*self.alpha[2] #theta
        #network_input[3] = (position[3]-target[3]-theta_s(position[0], position[1]))*self.alpha[3]
        #Teta_t = 0

        while self.running:
            debut = time.time()
            command = self.network.runNN(network_input) # propage erreur et calcul vitesses instant t
            
            command[0]=-command[0];
            #command[1]=-command[1];
            command[2]=-command[2];

            #print(command)
            
            alpha_x = 1/1.453
            alpha_z = 1/0.9
            alpha_theta = 1.0/math.pi
            #alpha_teta = 1.0/(math.pi)

            #crit_av= alpha_x*alpha_x*(position[0]-target[0])*(position[0]-target[0]) + alpha_y*alpha_y*(position[1]-target[1])*(position[1]-target[1]) + alpha_theta*alpha_theta*(position[2]-target[2])*(position[2]-target[2])


            self.robot.set_motor_velocity(command) # applique vitesses roues instant t,
            time.sleep(0.050) # attend delta t
            position = self.robot.get_position() #  obtient nvlle pos robot instant t+1

            network_input[0] = (position[0]-target[0])*self.alpha[0]
            network_input[1] = (position[1]-target[1])*self.alpha[1]
            network_input[2] = (position[2]-target[2])*self.alpha[2]
            #network_input[3] = (position[3]-target[3]-theta_s(position[0], position[1]))*self.alpha[3]

            #crit_ap= alpha_x*alpha_x*(position[0]-target[0])*(position[0]-target[0]) + alpha_y*alpha_y*(position[1]-target[1])*(position[1]-target[1]) + alpha_theta*alpha_theta*(position[2]-target[2]-theta_s(position[0], position[1]))*(position[2]-target[2]-theta_s(position[0], position[1]))

            if self.training:
                delta_t = (time.time()-debut)

                print(position);
                
                #print(((position[0]-self.robot.l3*math.cos(position[2]))**2+(position[1]-self.robot.l3*math.sin(position[2]))**2 - self.robot.l1**2 - self.robot.l2**2)/(2*self.robot.l1*self.robot.l2))

                q2=math.acos(((position[0]-self.robot.l3*math.cos(position[2]))**2+((position[1]-self.robot.h)-self.robot.l3*math.sin(position[2]))**2 - (self.robot.l1)**2 - (self.robot.l2)**2)/(2*self.robot.l1*self.robot.l2))

                #print(((self.robot.l1*math.cos(position[2]-q2)+self.robot.l2*math.cos(position[2]))*(position[0]-self.robot.l3*math.cos(position[2]))+(position[1]-self.robot.l3*math.sin(position[2]))*(self.robot.l1*math.sin(position[2]-q2)+self.robot.l2*math.sin(position[2])))/
                                #(self.robot.l1**2 + self.robot.l2**2 + 2*self.robot.l1*self.robot.l2*(math.cos(position[2])+math.sin(position[2])) ) )               

                q3=math.acos(((self.robot.l1*math.cos(position[2]-q2)+self.robot.l2*math.cos(position[2]))*(position[0]-self.robot.l3*math.cos(position[2]))+((position[1]-self.robot.h)-self.robot.l3*math.sin(position[2]))*(self.robot.l1*math.sin(position[2]-q2)+self.robot.l2*math.sin(position[2])))/(self.robot.l1**2 + self.robot.l2**2 + 2*self.robot.l1*self.robot.l2*(math.cos(position[2])+math.sin(position[2])) ))
                

                grad = [
                    (-2/delta_t)*(alpha_x*alpha_x*(position[0]-target[0])*delta_t*(-self.robot.l1*math.sin(position[2]-q3-q2)-self.robot.l2*math.sin(position[2]-q3)-self.robot.l3*math.sin(position[2]))
                    +alpha_z*alpha_z*(position[1]-target[1])*delta_t*(self.robot.l1*math.cos(position[2]-q3-q2)+self.robot.l2*math.cos(position[2]-q3)+self.robot.l3*math.cos(position[2]))
                    -alpha_theta*alpha_theta*(position[2]-target[2])*delta_t),

                    (-2/delta_t)*(alpha_x*alpha_x*(position[0]-target[0])*delta_t*(-self.robot.l2*math.sin(position[2]-q3)-self.robot.l3*math.sin(position[2]))
                    +alpha_z*alpha_z*(position[1]-target[1])*delta_t*(self.robot.l2*math.cos(position[2]-q3)+self.robot.l3*math.cos(position[2]))
                    +alpha_theta*alpha_theta*(position[2]-target[2])*delta_t),

                    (-2/delta_t)*(alpha_x*alpha_x*(position[0]-target[0])*delta_t*(-self.robot.l3*math.sin(position[2]))
                    +alpha_z*alpha_z*(position[1]-target[1])*delta_t*(self.robot.l3*math.cos(position[2]))
                    +alpha_theta*alpha_theta*(position[2]-target[2])*delta_t)
                    ]

                # The two args after grad are the gradient learning steps for t+1 and t
                # si critere augmente on BP un bruit fction randon_update, sion on BP le gradient

                #if (crit_ap <= crit_av) :
                self.network.backPropagate(grad, 1.2, 0.12) # grad, pas d'app, moment
                #else :
                    #self.network.random_update(0.001)
                    #self.network.backPropagate(grad,1.2,0.12)

        self.robot.set_motor_velocity([0,0,0]) # stop  apres arret  du prog d'app
        #position = self.robot.get_position() #  obtient nvlle pos robot instant t+1
                #Teta_t=position[2]

        self.running = False
